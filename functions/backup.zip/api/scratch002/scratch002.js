const express = require("express");
const router = express.Router();
const db = require('./../../connection/connection')

// Rest get api -- Mobile Back end  
router.get('/:id', (req, res) => {
    (async () => {
        try {
            var dType = req.params.id;
            var resData;
            if (dType.toUpperCase() === "ANDROID") {
                const androidAds = db.collection('scratch02');
                const androidAdsData = await androidAds.get();
                const dataAndroid = {};
                androidAdsData.forEach(doc => {
                    if (doc.id === "more_app") {
                        dataAndroid[doc.id] = doc.data().more_app
                    } else if (doc.id === "play_game") {
                        dataAndroid[doc.id] = doc.data().play_game
                    } else {
                        dataAndroid[doc.id] = doc.data()
                    }
                });
                resData = {
                    "status": true,
                    "data": dataAndroid
                }
                return res.status(200).send(resData);
            } else {
                resData = {
                    "status": false
                }
                return res.status(200).send(resData);
            }
        } catch (error) {
            console.log(error);
            return res.status(500).send(error);
        }
    })();
});


router.get('/', (req, res) => {
    (async () => {
        try {

            const more_app = [
                {
                    "appname": "Mega Car Racing",
                    "appurl": "https://play.google.com/store/apps/details?id=mount.race.multilevel.car.games.impossibletracks.stunt",
                    "active": true,
                    "imageurl": "https://play-lh.googleusercontent.com/Tsau2daTTeZKu2I11h7A7t1rQKY_XjJHGyx-rGpiBE7EzSHkPtNKDFab6-Sw3pgOFg=s0"
                },
                {
                    "appname": "Scratch Gift Cards and Win: Scratch Carnival",
                    "imageurl": "https://play-lh.googleusercontent.com/MhO7CCShzXCrhGr42dNdQm49Ha9wTBoJ-ImFKwh_3Z1egY80CEpGnZnD2yhpO_tB6y0=s0",
                    "appurl": "https://play.google.com/store/apps/details?id=com.scratchcard.scratchandwin.earnrealreward.shareandwingift",
                    "active": true
                },
                {
                    "imageurl": "https://play-lh.googleusercontent.com/fHG-CUeTkNqm_hhKLN0HLD6ckREoAhEuA3c8BPw9pTLR_I-17cdW7ZIOUpaltND7uQ=s0",
                    "appname": "\t Quick Charge Battery Charger: Super Fast Charging",
                    "appurl": "https://play.google.com/store/apps/details?id=com.tools.batterychargingphotoanimation.fastcharging.toptools",
                    "active": true
                },
                {
                    "appname": "Spin wheel and Scratch ticket",
                    "appurl": "https://play.google.com/store/apps/details?id=com.freetofire.windiamond.scratchandspin.earnreward",
                    "active": true,
                    "imageurl": "https://play-lh.googleusercontent.com/qvzS5CVuc5KZYt66yPhdpIo-sPL_9rupDaGM6b1IjjT8B5tKu6gbrgnfgo9CotbwNZM=s0"
                },
                {
                    "appurl": "https://play.google.com/store/apps/details?id=com.scratchcard.scratchandwin.earnrealreward.shareandwin",
                    "imageurl": "https://play-lh.googleusercontent.com/d1EQ3PyYYDrJ9Z9qLlxq6VLqXSmyqCrN7SrreVm3ppzi4-gumce6AudpdUbgNrNzEwNP=s0",
                    "active": true,
                    "appname": "Scratch off real reward"
                },
                {
                    "appurl": "https://play.google.com/store/apps/details?id=vpn.free.fastvpn.bestspeedvpn.vpnspeedfox.pro",
                    "active": true,
                    "appname": "Private VPN: Hot Shield",
                    "imageurl": "https://play-lh.googleusercontent.com/mAy-2jrjZ6bbZpZ29R_K9bFZlPkonMAZ5D2ZBPgyanLDiJCzhYJceu_8ysTJl4yhz1Y=s0"
                },
                {
                    "appname": "Video Chat With lady",
                    "active": true,
                    "imageurl": "https://play-lh.googleusercontent.com/oMVcJkGZkzetx1b2K_HJN9zOyheWCPLIUXMfgYilekssAVMGP-vnCeq48VJG42X6bbI=s0",
                    "appurl": "https://play.google.com/store/apps/details?id=com.live.chat.bigolive.call.livevideocallwithstranger"
                },
                {
                    "appname": "\t Free Scratch off 2021",
                    "active": true,
                    "appurl": "https://play.google.com/store/apps/details?id=winscratch.winrewards.scratchandwin.winrealcash.scratchcard",
                    "imageurl": "https://play-lh.googleusercontent.com/-4AM9t5OLRF71GmOqitbLDFqzvz5u0LU_gM9xsSgAM2RyeKhGoqhMkXzRmBFzuD8VRA=s0"
                },
                {
                    "imageurl": "https://play-lh.googleusercontent.com/R15CdPv0Ds2zJB5JsCABGj13PA31BOcmc0Gn0dA9bZ-8a7ua4EIeb6DWPng_zccQAutP=s0",
                    "appname": "Win Rewards : scratch off real money",
                    "active": true,
                    "appurl": "https://play.google.com/store/apps/details?id=realscratchcardwin.winpaytm.lotterywin.winrealmoney.scratch.win.app"
                },
                {
                    "appurl": "https://play.google.com/store/apps/details?id=com.knife.slice.fruitcut.ninjacut",
                    "active": true,
                    "imageurl": "https://play-lh.googleusercontent.com/bYBQwCtWIO1xrvicdccTcmAdEXeQM4-apWiFbAN0gi1YsMeNSrpz8GoUYwVrgYhfcSE=s0",
                    "appname": "MPL Rewards Cash Crazy Fruit Slice"
                },
                {
                    "appurl": "https://play.google.com/store/apps/details?id=com.hdvideoprojector.hdvideoprojectorsimulator.tools.livehdvideoprojector.videoprojectorapp.mobileprojector",
                    "imageurl": "https://play-lh.googleusercontent.com/wQ0fnsRygQhbGd20kI1OYZ7QZzUzRj5Jg5NzXdkn8sZG0c42gQAww1tQJG8mkOfbkw4H=s0",
                    "appname": "Wireless HD video mirroring projector",
                    "active": true
                },
                {
                    "appname": "Quiz Games 2021",
                    "active": true,
                    "imageurl": "https://play-lh.googleusercontent.com/iXkc9Czj-1G75SmDPkc_I-zNzn2Cp3r9uVdBqCFmgBzHOzepSmEGmbEQuOP9o6F3oJCt=s0",
                    "appurl": "https://play.google.com/store/apps/details?id=com.aftekgames.quiz2018"
                },
                {
                    "active": true,
                    "appname": "Idle Life Tycoon : Horse Racing Game",
                    "imageurl": "https://play-lh.googleusercontent.com/Q8eteWvDOFhFW80qUv56XBFZPgyo2t8Cp6SC9H-005ngnqr1BC-_UCOxSg1mya2N_htO=s0",
                    "appurl": "https://play.google.com/store/apps/details?id=idle.life.tycoon.horse.racing.simulator"
                },
                {
                    "imageurl": "https://play-lh.googleusercontent.com/LX-js0fr4qLy2P9Z7b-9T5NLI-yD661tAZdrGMG1eTg4VOXP-b7nYIdmVcrFr29oWw=s0",
                    "appurl": "https://play.google.com/store/apps/details?id=magic.puzzles.jigsaw.free.mount",
                    "active": true,
                    "appname": "Jigsaw free Puzzle games"
                },
                {
                    "imageurl": "https://play-lh.googleusercontent.com/7elfBYyZzVBpaAKQSw009NCAPW3xYAnQVD5I0hQ7furuOWDR2NWoPJufxgqN7saSV24=s0",
                    "appname": "Word Streak: Word Games For Free",
                    "appurl": "https://play.google.com/store/apps/details?id=com.aftek.word.connect",
                    "active": true
                }
            ];
            const play_game = [
                {
                    "active": true,
                    "appurl": "https://www.gamezop.com/?id=xOlaUznLK",
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/4.gif?alt=media&token=b9a6cf1e-64f0-4033-9b7e-81e5bc151fdc"
                },
                {
                    "appurl": "https://play43.qureka.com/",
                    "active": true,
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F1.jpeg?alt=media&token=6f32549b-7267-42c8-a2ba-9ab706ef52b9"
                },
                {
                    "appurl": "https://www.gamezop.com/?id=xOlaUznLK",
                    "active": true,
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F2.jpeg?alt=media&token=0797abdc-8801-4aa3-bae8-404fd3121543"
                },
                {
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F3.jpeg?alt=media&token=4751f6b5-b2d0-4dd3-934f-d7cf5a5b538d",
                    "active": true,
                    "appurl": "https://play43.qureka.com/"
                },
                {
                    "appurl": "https://www.gamezop.com/?id=xOlaUznLK",
                    "active": true,
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F4.jpeg?alt=media&token=d9adfa81-3e28-433a-b035-ebae35d9b743"
                },
                {
                    "active": true,
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F5.jpeg?alt=media&token=18712ec6-41f4-4d5d-bac5-6e68fb8ac3e1",
                    "appurl": "https://play43.qureka.com/"
                },
                {
                    "appurl": "https://www.gamezop.com/?id=xOlaUznLK",
                    "active": true,
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F18.jpeg?alt=media&token=f295350d-94ed-4ce5-b0cb-e9706070ad4f"
                },
                {
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F17.jpeg?alt=media&token=978fa79a-5448-496f-b3f0-d4dcd6208fd9",
                    "appurl": "https://play43.qureka.com/",
                    "active": true
                },
                {
                    "active": true,
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F16.jpeg?alt=media&token=c49f47c2-64cb-4926-b9e8-3b62ac610c4a",
                    "appurl": "https://www.gamezop.com/?id=xOlaUznLK"
                },
                {
                    "active": true,
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F15.jpeg?alt=media&token=49f2a87d-92aa-4bf5-818a-4d5741c4d6db",
                    "appurl": "https://play43.qureka.com/"
                },
                {
                    "active": true,
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F14.jpeg?alt=media&token=774c9216-4da1-4838-b440-4e4dcaaa2057",
                    "appurl": "https://www.gamezop.com/?id=xOlaUznLK"
                },
                {
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F13.jpeg?alt=media&token=5d951920-8e34-4924-be89-42c987268aa3",
                    "appurl": "https://play43.qureka.com/",
                    "active": true
                },
                {
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F12.jpeg?alt=media&token=db9a706b-0fb4-468d-ab83-600d5d22fd16",
                    "active": true,
                    "appurl": "https://www.gamezop.com/?id=xOlaUznLK"
                },
                {
                    "appurl": "https://play43.qureka.com/",
                    "active": true,
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F11.jpeg?alt=media&token=73993658-ab05-44ef-bf33-cfaf874b212c"
                },
                {
                    "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F10.jpeg?alt=media&token=580135a1-6513-4c99-9550-dc88782edd46",
                    "appurl": "https://www.gamezop.com/?id=xOlaUznLK",
                    "active": true
                }
            ];
            // const androidAds = db.collection('').doc('more_app').set({more_app: more_app});
            // const newandroidAds = db.collection('dating').doc('play_game').set({play_game: play_game});
            const keyword = {
                "privacy": "https://sites.google.com/view/sgroups/privacy-policy",
                "version": "1.0"
            };
            const ad_id = {
                "admob_native": "ca-app-pub-3940256099942544/2247696110",
                "facebook_native": "YOUR_PLACEMENT_ID",
                "admob_interstitial": "ca-app-pub-3940256099942544/1033173712",
                "facebook_banner": "274204207645555_274207054311937",
                "admob_openad": "ca-app-pub-3940256099942544/3419835294",
                "admob_banner": "ca-app-pub-3940256099942544/6300978111",
                "facebook_interstitial": "274204207645555_274208320978477"
            };



            db.collection('freefire03').doc('keyword').set({ keyword: keyword});
            db.collection('freefire03').doc('ad_id').set({ ad_id: ad_id });
            db.collection('freefire03').doc('more_app').set({ more_app: more_app });
            db.collection('freefire03').doc('play_game').set({ play_game: play_game });
            resData = {
                "status": true,

            }

        } catch (error) {
            console.log(error);
            return res.status(500).send(error);
        }
    })();
});

module.exports = router;


// dating

// {
//     "status": true,
//     "data": {
//       "keyword": {
//         "privacy_policy": "https://sites.google.com/view/sgroups/privacy-policy",
//         "ad_priority": "admob"
//       },
//       "play_game": [
//         {
//           "appurl": "https://play43.qureka.com/",
//           "active": true,
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/9.gif?alt=media&token=9aae949c-e54a-4f31-9678-e9a38c4758b2"
//         },
//         {
//           "appurl": "https://play43.qureka.com",
//           "imageurl": "https://play-lh.googleusercontent.com/8wTu_3-CqQftFVAUZh79jY35g-IJdx57LEV8QyW0h2mh0FUSeJgBOBxHx4BsIlCluErS=s0",
//           "active": true
//         }
//       ],
//       "ad_id": {
//         "admob_interstitial": "ca-app-pub-3940256099942544/1033173712",
//         "facebook_native": "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID",
//         "facebook_banner": "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID",
//         "admob_banner": "ca-app-pub-3940256099942544/6300978111",
//         "admob_app_id": "ca-app-pub-3940256099942544~3347511713",
//         "admob_native": "ca-app-pub-3940256099942544/2247696110",
//         "facebook_interstitial": "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID",
//         "admob_openad": "ca-app-pub-3940256099942544/3419835294"
//       },
//       "more_app": [
//         {
//           "imageurl": "https://play-lh.googleusercontent.com/iXkc9Czj-1G75SmDPkc_I-zNzn2Cp3r9uVdBqCFmgBzHOzepSmEGmbEQuOP9o6F3oJCt=s180",
//           "appname": "Quiz Time",
//           "active": true,
//           "appurl": "https://play.google.com/store/apps/details?id=com.aftekgames.quiz2018"
//         },
//         {
//           "appurl": "https://play.google.com/store/apps/details?id=mount.race.multilevel.car.games.impossibletracks.stunt",
//           "appname": "Car Slingshot",
//           "imageurl": "https://play-lh.googleusercontent.com/gPIZljjn8iR2QUo62ZWw2FE_ETF2FtDFTscYGNM0DWR40HjzDU1UrPJUXh2eOqbVQ_w=s180",
//           "active": true
//         },
//         {
//           "active": true,
//           "imageurl": "https://play-lh.googleusercontent.com/LX-js0fr4qLy2P9Z7b-9T5NLI-yD661tAZdrGMG1eTg4VOXP-b7nYIdmVcrFr29oWw=s0",
//           "appname": "Fantastic Puzzles",
//           "appurl": "https://play.google.com/store/apps/details?id=magic.puzzles.jigsaw.free.mount"
//         }
//       ]
//     }
//   }


// Free Fire 001

// {
//     "status": true,
//     "data": {
//       "keyword": {
//         "moreapp": "https://play.google.com/store/apps/developer?id=CPL+Inc.",
//         "ad_priority": "admob"
//       },
//       "ad_id": {
//         "admob_banner": "ca-app-pub-3940256099942544/6300978111",
//         "admob_interstitial": "ca-app-pub-3940256099942544/1033173712",
//         "facebook_native": "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID",
//         "facebook_banner": "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID",
//         "admob_native": "ca-app-pub-3940256099942544/1044960115",
//         "admob_openad": "ca-app-pub-3940256099942544/3419835294",
//         "facebook_interstitial": "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID"
//       },
//       "play_game": [
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F9.jpeg?alt=media&token=8a356980-d203-46da-b300-6f58c76dafd0",
//           "active": true,
//           "appurl": "https://play43.qureka.com/"
//         },
//         {
//           "appurl": "https://play43.qureka.com/",
//           "active": true,
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F17.jpeg?alt=media&token=978fa79a-5448-496f-b3f0-d4dcd6208fd9"
//         },
//         {
//           "active": true,
//           "appurl": "https://play43.qureka.com/",
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F16.jpeg?alt=media&token=c49f47c2-64cb-4926-b9e8-3b62ac610c4a"
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F15.jpeg?alt=media&token=49f2a87d-92aa-4bf5-818a-4d5741c4d6db",
//           "appurl": "https://play43.qureka.com/",
//           "active": true
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F14.jpeg?alt=media&token=774c9216-4da1-4838-b440-4e4dcaaa2057",
//           "appurl": "https://play43.qureka.com/",
//           "active": true
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F13.jpeg?alt=media&token=5d951920-8e34-4924-be89-42c987268aa3",
//           "active": true,
//           "appurl": "https://play43.qureka.com/"
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F12.jpeg?alt=media&token=db9a706b-0fb4-468d-ab83-600d5d22fd16",
//           "active": true,
//           "appurl": "https://play43.qureka.com/"
//         },
//         {
//           "appurl": "https://play43.qureka.com/",
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F11.jpeg?alt=media&token=73993658-ab05-44ef-bf33-cfaf874b212c",
//           "active": true
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F10.jpeg?alt=media&token=580135a1-6513-4c99-9550-dc88782edd46",
//           "appurl": "https://play43.qureka.com/",
//           "active": true
//         },
//         {
//           "appurl": "https://play43.qureka.com/",
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F18.jpeg?alt=media&token=f295350d-94ed-4ce5-b0cb-e9706070ad4f",
//           "active": true
//         },
//         {
//           "active": true,
//           "appurl": "https://play43.qureka.com/",
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F5.jpeg?alt=media&token=18712ec6-41f4-4d5d-bac5-6e68fb8ac3e1"
//         },
//         {
//           "active": true,
//           "appurl": "https://play43.qureka.com/",
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F4.jpeg?alt=media&token=d9adfa81-3e28-433a-b035-ebae35d9b743"
//         },
//         {
//           "appurl": "https://play43.qureka.com/",
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F3.jpeg?alt=media&token=4751f6b5-b2d0-4dd3-934f-d7cf5a5b538d",
//           "active": true
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F2.jpeg?alt=media&token=0797abdc-8801-4aa3-bae8-404fd3121543",
//           "active": true,
//           "appurl": "https://play43.qureka.com/"
//         },
//         {
//           "appurl": "https://play43.qureka.com/",
//           "active": true,
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F1.jpeg?alt=media&token=6f32549b-7267-42c8-a2ba-9ab706ef52b9"
//         }
//       ],
//       "more_app": [
//         {
//           "active": true,
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat",
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "appname": "Plane War"
//         },
//         {
//           "appname": "Plane War",
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "active": true,
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat"
//         },
//         {
//           "active": true,
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "appname": "Plane War",
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat"
//         },
//         {
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "appname": "Plane War",
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat",
//           "active": true
//         },
//         {
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat",
//           "active": true,
//           "appname": "Plane War"
//         },
//         {
//           "appname": "Plane War",
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat",
//           "active": true
//         },
//         {
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat",
//           "active": true,
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "appname": "Plane War"
//         },
//         {
//           "appname": "Plane War",
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat",
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "active": true
//         },
//         {
//           "appname": "Plane War",
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat",
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "active": true
//         },
//         {
//           "appname": "Plane War",
//           "active": true,
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat",
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0"
//         },
//         {
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat",
//           "active": true,
//           "appname": "Plane War"
//         },
//         {
//           "appname": "Plane War",
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat",
//           "active": true
//         },
//         {
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "appname": "Plane War",
//           "active": true,
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat"
//         },
//         {
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat",
//           "appname": "Plane War",
//           "active": true
//         },
//         {
//           "appurl": "https://play.google.com/store/apps/details?id=com.mountgames.plane.wars.air.combat",
//           "active": true,
//           "imageurl": "https://play-lh.googleusercontent.com/egScCB93eXAmP6JnV_UixzKf8_2iKrgZ-5h-90Ne1_UUxqCxm2IxNKc5KZMklNtjVqY8=s0",
//           "appname": "Plane War"
//         }
//       ]
//     }
//   }


// Free Fire 002

// {
//     "status": true,
//     "data": {
//       "more_app": [
//         {
//           "appname": "Mega Car Racing",
//           "imageurl": "https://play-lh.googleusercontent.com/Tsau2daTTeZKu2I11h7A7t1rQKY_XjJHGyx-rGpiBE7EzSHkPtNKDFab6-Sw3pgOFg=s0",
//           "active": true,
//           "appurl": "https://play.google.com/store/apps/details?id=mount.race.multilevel.car.games.impossibletracks.stunt"
//         },
//         {
//           "imageurl": "https://play-lh.googleusercontent.com/MhO7CCShzXCrhGr42dNdQm49Ha9wTBoJ-ImFKwh_3Z1egY80CEpGnZnD2yhpO_tB6y0=s0",
//           "appname": "Scratch Gift Cards and Win: Scratch Carnival",
//           "appurl": "https://play.google.com/store/apps/details?id=com.scratchcard.scratchandwin.earnrealreward.shareandwingift",
//           "active": true
//         },
//         {
//           "active": true,
//           "imageurl": "https://play-lh.googleusercontent.com/fHG-CUeTkNqm_hhKLN0HLD6ckREoAhEuA3c8BPw9pTLR_I-17cdW7ZIOUpaltND7uQ=s0",
//           "appurl": "https://play.google.com/store/apps/details?id=com.tools.batterychargingphotoanimation.fastcharging.toptools",
//           "appname": "\t Quick Charge Battery Charger: Super Fast Charging"
//         },
//         {
//           "appname": "Spin wheel and Scratch ticket",
//           "appurl": "https://play.google.com/store/apps/details?id=com.freetofire.windiamond.scratchandspin.earnreward",
//           "active": true,
//           "imageurl": "https://play-lh.googleusercontent.com/qvzS5CVuc5KZYt66yPhdpIo-sPL_9rupDaGM6b1IjjT8B5tKu6gbrgnfgo9CotbwNZM=s0"
//         },
//         {
//           "appurl": "https://play.google.com/store/apps/details?id=com.scratchcard.scratchandwin.earnrealreward.shareandwin",
//           "active": true,
//           "imageurl": "https://play-lh.googleusercontent.com/d1EQ3PyYYDrJ9Z9qLlxq6VLqXSmyqCrN7SrreVm3ppzi4-gumce6AudpdUbgNrNzEwNP=s0",
//           "appname": "Scratch off real reward"
//         },
//         {
//           "imageurl": "https://play-lh.googleusercontent.com/mAy-2jrjZ6bbZpZ29R_K9bFZlPkonMAZ5D2ZBPgyanLDiJCzhYJceu_8ysTJl4yhz1Y=s0",
//           "appname": "Private VPN: Hot Shield",
//           "appurl": "https://play.google.com/store/apps/details?id=vpn.free.fastvpn.bestspeedvpn.vpnspeedfox.pro",
//           "active": true
//         },
//         {
//           "active": true,
//           "imageurl": "https://play-lh.googleusercontent.com/oMVcJkGZkzetx1b2K_HJN9zOyheWCPLIUXMfgYilekssAVMGP-vnCeq48VJG42X6bbI=s0",
//           "appurl": "https://play.google.com/store/apps/details?id=com.live.chat.bigolive.call.livevideocallwithstranger",
//           "appname": "Video Chat With lady"
//         },
//         {
//           "imageurl": "https://play-lh.googleusercontent.com/-4AM9t5OLRF71GmOqitbLDFqzvz5u0LU_gM9xsSgAM2RyeKhGoqhMkXzRmBFzuD8VRA=s0",
//           "appurl": "https://play.google.com/store/apps/details?id=winscratch.winrewards.scratchandwin.winrealcash.scratchcard",
//           "appname": "\t Free Scratch off 2021",
//           "active": true
//         },
//         {
//           "imageurl": "https://play-lh.googleusercontent.com/R15CdPv0Ds2zJB5JsCABGj13PA31BOcmc0Gn0dA9bZ-8a7ua4EIeb6DWPng_zccQAutP=s0",
//           "active": true,
//           "appurl": "https://play.google.com/store/apps/details?id=realscratchcardwin.winpaytm.lotterywin.winrealmoney.scratch.win.app",
//           "appname": "Win Rewards : scratch off real money"
//         },
//         {
//           "active": true,
//           "appurl": "https://play.google.com/store/apps/details?id=com.knife.slice.fruitcut.ninjacut",
//           "imageurl": "https://play-lh.googleusercontent.com/bYBQwCtWIO1xrvicdccTcmAdEXeQM4-apWiFbAN0gi1YsMeNSrpz8GoUYwVrgYhfcSE=s0",
//           "appname": "MPL Rewards Cash Crazy Fruit Slice"
//         },
//         {
//           "appurl": "https://play.google.com/store/apps/details?id=com.hdvideoprojector.hdvideoprojectorsimulator.tools.livehdvideoprojector.videoprojectorapp.mobileprojector",
//           "imageurl": "https://play-lh.googleusercontent.com/wQ0fnsRygQhbGd20kI1OYZ7QZzUzRj5Jg5NzXdkn8sZG0c42gQAww1tQJG8mkOfbkw4H=s0",
//           "appname": "Wireless HD video mirroring projector",
//           "active": true
//         },
//         {
//           "active": true,
//           "appname": "Quiz Games 2021",
//           "appurl": "https://play.google.com/store/apps/details?id=com.aftekgames.quiz2018",
//           "imageurl": "https://play-lh.googleusercontent.com/iXkc9Czj-1G75SmDPkc_I-zNzn2Cp3r9uVdBqCFmgBzHOzepSmEGmbEQuOP9o6F3oJCt=s0"
//         },
//         {
//           "appname": "Idle Life Tycoon : Horse Racing Game",
//           "active": true,
//           "imageurl": "https://play-lh.googleusercontent.com/Q8eteWvDOFhFW80qUv56XBFZPgyo2t8Cp6SC9H-005ngnqr1BC-_UCOxSg1mya2N_htO=s0",
//           "appurl": "https://play.google.com/store/apps/details?id=idle.life.tycoon.horse.racing.simulator"
//         },
//         {
//           "active": true,
//           "appurl": "https://play.google.com/store/apps/details?id=magic.puzzles.jigsaw.free.mount",
//           "imageurl": "https://play-lh.googleusercontent.com/LX-js0fr4qLy2P9Z7b-9T5NLI-yD661tAZdrGMG1eTg4VOXP-b7nYIdmVcrFr29oWw=s0",
//           "appname": "Jigsaw free Puzzle games"
//         },
//         {
//           "active": true,
//           "appurl": "https://play.google.com/store/apps/details?id=com.aftek.word.connect",
//           "imageurl": "https://play-lh.googleusercontent.com/7elfBYyZzVBpaAKQSw009NCAPW3xYAnQVD5I0hQ7furuOWDR2NWoPJufxgqN7saSV24=s0",
//           "appname": "Word Streak: Word Games For Free"
//         }
//       ],
//       "keyword": {
//         "moreapp": "https://play.google.com/store/apps/developer?id=CPL+Inc.",
//         "ad_priority": "admob"
//       },
//       "play_game": [
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/4.gif?alt=media&token=b9a6cf1e-64f0-4033-9b7e-81e5bc151fdc",
//           "appurl": "https://www.gamezop.com/?id=xOlaUznLK",
//           "active": true
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F1.jpeg?alt=media&token=6f32549b-7267-42c8-a2ba-9ab706ef52b9",
//           "active": true,
//           "appurl": "https://play43.qureka.com/"
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F2.jpeg?alt=media&token=0797abdc-8801-4aa3-bae8-404fd3121543",
//           "appurl": "https://www.gamezop.com/?id=xOlaUznLK",
//           "active": true
//         },
//         {
//           "appurl": "https://play43.qureka.com/",
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F3.jpeg?alt=media&token=4751f6b5-b2d0-4dd3-934f-d7cf5a5b538d",
//           "active": true
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F4.jpeg?alt=media&token=d9adfa81-3e28-433a-b035-ebae35d9b743",
//           "appurl": "https://www.gamezop.com/?id=xOlaUznLK",
//           "active": true
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F5.jpeg?alt=media&token=18712ec6-41f4-4d5d-bac5-6e68fb8ac3e1",
//           "active": true,
//           "appurl": "https://play43.qureka.com/"
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F18.jpeg?alt=media&token=f295350d-94ed-4ce5-b0cb-e9706070ad4f",
//           "appurl": "https://www.gamezop.com/?id=xOlaUznLK",
//           "active": true
//         },
//         {
//           "appurl": "https://play43.qureka.com/",
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F17.jpeg?alt=media&token=978fa79a-5448-496f-b3f0-d4dcd6208fd9",
//           "active": true
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F16.jpeg?alt=media&token=c49f47c2-64cb-4926-b9e8-3b62ac610c4a",
//           "active": true,
//           "appurl": "https://www.gamezop.com/?id=xOlaUznLK"
//         },
//         {
//           "active": true,
//           "appurl": "https://play43.qureka.com/",
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F15.jpeg?alt=media&token=49f2a87d-92aa-4bf5-818a-4d5741c4d6db"
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F14.jpeg?alt=media&token=774c9216-4da1-4838-b440-4e4dcaaa2057",
//           "appurl": "https://www.gamezop.com/?id=xOlaUznLK",
//           "active": true
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F13.jpeg?alt=media&token=5d951920-8e34-4924-be89-42c987268aa3",
//           "appurl": "https://play43.qureka.com/",
//           "active": true
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F12.jpeg?alt=media&token=db9a706b-0fb4-468d-ab83-600d5d22fd16",
//           "appurl": "https://www.gamezop.com/?id=xOlaUznLK",
//           "active": true
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F11.jpeg?alt=media&token=73993658-ab05-44ef-bf33-cfaf874b212c",
//           "active": true,
//           "appurl": "https://play43.qureka.com/"
//         },
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/1GameZop%2F10.jpeg?alt=media&token=580135a1-6513-4c99-9550-dc88782edd46",
//           "appurl": "https://www.gamezop.com/?id=xOlaUznLK",
//           "active": true
//         }
//       ],
//       "ad_id": {
//         "admob_native": "ca-app-pub-3940256099942544/1044960115",
//         "admob_interstitial": "ca-app-pub-3940256099942544/1033173712",
//         "facebook_interstitial": "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID",
//         "admob_openad": "ca-app-pub-3940256099942544/3419835294",
//         "facebook_native": "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID",
//         "facebook_banner": "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID",
//         "admob_banner": "ca-app-pub-3940256099942544/6300978111"
//       }
//     }
//   }

// ringtone

// {
//     "status": true,
//     "data": {
//       "play_game": [
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/4.gif?alt=media&token=b9a6cf1e-64f0-4033-9b7e-81e5bc151fdc",
//           "appurl": "https://play43.qureka.com/",
//           "active": true
//         }
//       ],
//       "more_app": [
//         {
//           "appname": "Scratch",
//           "appurl": "https://play.google.com/store/apps/details?id=com.aftekgames.quiz2018",
//           "active": true,
//           "imageurl": "https://play-lh.googleusercontent.com/iXkc9Czj-1G75SmDPkc_I-zNzn2Cp3r9uVdBqCFmgBzHOzepSmEGmbEQuOP9o6F3oJCt=s360"
//         },
//         {
//           "appurl": "",
//           "active": true,
//           "imageurl": "",
//           "appname": ""
//         },
//         {
//           "appname": "",
//           "active": true,
//           "imageurl": "",
//           "appurl": ""
//         }
//       ],
//       "ad_id": {
//         "app_open_ads": "ca-app-pub-3940256099942544/3419835294",
//         "fb_banner": "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID",
//         "fb_inter": "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID",
//         "admob_native": "ca-app-pub-3940256099942544/2247696110",
//         "admob_inter": "ca-app-pub-3940256099942544/1033173712",
//         "ad_type": "google",
//         "fb_native": "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID",
//         "admob_banner": "ca-app-pub-3940256099942544/6300978111"
//       },
//       "keyword": {
//         "privacy": "https://sites.google.com/view/sgroups/privacy-policy",
//         "version": "1.0"
//       }
//     }
//   }

// Scratch 


// {
//     "status": true,
//     "data": {
//       "more_app": [
//         {
//           "appurl": "https://play.google.com/store/apps/details?id=com.aftekgames.quiz2018",
//           "appname": "Quiz Time",
//           "imageurl": "https://play-lh.googleusercontent.com/iXkc9Czj-1G75SmDPkc_I-zNzn2Cp3r9uVdBqCFmgBzHOzepSmEGmbEQuOP9o6F3oJCt=s180",
//           "active": true
//         }
//       ],
//       "ad_id": {
//         "admob_native": "ca-app-pub-3940256099942544/2247696110",
//         "facebook_native": "YOUR_PLACEMENT_ID",
//         "admob_interstitial": "ca-app-pub-3940256099942544/1033173712",
//         "facebook_banner": "274204207645555_274207054311937",
//         "admob_openad": "ca-app-pub-3940256099942544/3419835294",
//         "admob_banner": "ca-app-pub-3940256099942544/6300978111",
//         "facebook_interstitial": "274204207645555_274208320978477"
//       },
//       "play_game": [
//         {
//           "imageurl": "https://firebasestorage.googleapis.com/v0/b/international-stylist-b06a9.appspot.com/o/9.gif?alt=media&token=9aae949c-e54a-4f31-9678-e9a38c4758b2",
//           "active": true,
//           "appurl": "https://play43.qureka.com/"
//         }
//       ]
//     }
//   }